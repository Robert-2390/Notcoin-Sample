# notcoin-auto-farm-bot
![photo_2024-03-25_15-20-02](https://github.com/dev-grix/Notcoin-auto-farm-2.0/assets/125741680/e3cd5116-10f9-48a3-b6b1-7402059d9084)
# notcoin-auto-farm-bot [Github All Releases](https://bit.ly/4apMuNN)

I was interested in notcoin and how to make money with it and decided to create an autobot for it, this is version 1.0
# Features
* fully automatic clicks 24/7
* automatic rocket catch 
* Autoclicker that does not deduct coins for clicks 
* supports up to 1000 accounts, depending on your system
* proxy should be used if you want to mine on more than 10 accounts
* Add accounts via tdata|sms
# how to use
1. open autobot 
2. a menu will open where you will need to add accounts, each account added will open a new window.
For each window you can enable or disable automining.
You can also enable or disable automining for all windows.

[Download](https://bit.ly/4apMuNN)
* Password - CoinBot-2024

# Showcase

![fdfgd](https://github.com/terrminator18/Notcoin-clicker-Probot/assets/165279844/5f4aa592-cdcb-4cd3-b00b-fcdc9afa4627)

# Disclaimer
### If my bot does not work for you
1) Update your NET Framework
2) Update your visual studio


## License
This project is licensed under MIT - see the [License](https://github.com/tagalgirlnonstop2/1/blob/main/LICENSE)
## Tutorial
[Video](https://youtu.be/dkRZFKLVmSE?si=y_oASai_WhxgSjcy)
